#ifndef DE_H
#define DE_H

// Reference DE of the M2 protocol, sharing kernel.h with the PSO: same shifted
// functions, same bounds, same shift mode, same double precision, same budget.
//   - DE/rand/1/bin, F = 0.5, CR = 0.3 (values of the reference article)
//   - generational (synchronous) replacement: every trial is evaluated against
//     the current generation, all trials are built before
//     any replacement (CPU and GPU share this meaning)
//   - real FE accounting: fe = P * (1 + nGen) <= maxFE
//   - CPU RNG mt19937_64 (fixed standard engine; distributions depend on the C++ library), GPU RNG cuRAND Philox: different streams,
//     agreement must be assessed statistically.
// This is NOT an implementation of the cudaDEi optimisations of the article
// (kernel fusion, shared memory, streams); those remain separate experiments.
#include "kernel.h"

struct DEParams {
    int    func  = F_SPHERE;
    int    dim   = 10;
    int    pop   = 50;                 // >= 4 (r1, r2, r3 distinct from i)
    long long maxFE = 100000;          // protocol : 10^4 * dim
    double F  = 0.5;
    double CR = 0.3;
    unsigned long long seed = 1234ULL;
};

struct DEResult {
    double            bestFit = 0.0;
    double            timeMs  = 0.0;   // initialisation + generations
    long long         fe      = 0;     // evaluations really performed
    int               gens    = 0;
    std::vector<real> gBest;
};

DEResult seq_de (const DEParams& prm, const std::vector<real>& shift);   // de.cpp (CPU)
DEResult cuda_de(const DEParams& prm, const std::vector<real>& shift);   // de.cu  (GPU)

#endif // DE_H
