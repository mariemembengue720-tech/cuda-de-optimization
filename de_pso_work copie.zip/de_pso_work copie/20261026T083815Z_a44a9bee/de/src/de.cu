#include "de.h"
#include "de_ops.h"
#include <cuda_runtime.h>
#include <curand_kernel.h>
#include <cstdio>
#include <cstdlib>

#define CUDA_CHECK(call) do {                                                  \
    cudaError_t status_ = (call);                                              \
    if (status_ != cudaSuccess) {                                              \
        fprintf(stderr, "CUDA error %s:%d: %s\n", __FILE__, __LINE__,          \
                cudaGetErrorString(status_));                                  \
        exit(1);                                                               \
    }                                                                          \
} while (0)

typedef curandStatePhilox4_32_10_t DERng;
struct DeviceIndex {
    DERng* state;
    __device__ int operator()(int n) { return (int)(curand(state) % (unsigned)n); }
};
// One thread per individual. Generational DE: kernel A builds and evaluates the
// trials of generation g against the population of generation g-1, kernel B
// performs the replacements; kernels are serialised by the stream, so no thread
// ever reads a value modified by another thread of the same generation.

__global__ void de_init_kernel(real* pop, double* fit, int P, int D,
                               real lo, real hi, int func, const real* shift,
                               unsigned long long seed, DERng* rng)
{
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= P) return;
    DERng st;
    curand_init(seed, (unsigned long long)i, 0, &st);
    for (int j = 0; j < D; j++)
        pop[(size_t)i * D + j] = lo + (hi - lo) * (real)curand_uniform_double(&st);
    rng[i] = st;
    fit[i] = fitness(&pop[(size_t)i * D], 1, D, func, shift);
}

__global__ void de_trial_kernel(const real* pop, real* trial, int P, int D,
                                real lo, real hi, int func, const real* shift,
                                double F, double CR, DERng* rng
#ifdef DE_TESTING
                                , const int* donor_tape = nullptr, const double* uniform_tape = nullptr
#endif
                                )
{
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= P) return;
    DERng st = rng[i];
    DeviceIndex draw{&st};
    int r1, r2, r3;
    int jr;
#ifdef DE_TESTING
    if (donor_tape) {
        r1=donor_tape[i*4];r2=donor_tape[i*4+1];r3=donor_tape[i*4+2];jr=donor_tape[i*4+3];
    } else
#endif
    {
        de_donors(draw, P, i, r1, r2, r3); jr=draw(D);
    }
    for (int j = 0; j < D; j++) {
        double u;
#ifdef DE_TESTING
        if (uniform_tape) u=uniform_tape[i*D+j]; else
#endif
        u=curand_uniform_double(&st);
        const bool cross = u <= CR || j == jr;
        trial[(size_t)i * D + j] = de_coordinate(pop, D, i, r1, r2, r3, j,
                                                cross, (real)F, lo, hi);
    }
    rng[i] = st;
}

__global__ void de_select_kernel(real* pop, const real* trial, double* fit,
                                 int P, int D, int func, const real* shift)
{
    const int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= P) return;
    const double tf = fitness(&trial[(size_t)i * D], 1, D, func, shift);
    if (tf <= fit[i]) {
        for (int j = 0; j < D; j++) pop[(size_t)i * D + j] = trial[(size_t)i * D + j];
        fit[i] = tf;
    }
}

DEResult cuda_de(const DEParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 4 || D < 1 || (int)shift.size() < D) {
        fprintf(stderr, "cuda_de: invalid parameters (pop >= 4, dim >= 1, shift size >= dim)\n");
        exit(1);
    }
    const BenchInfo bi = bench_info(prm.func);
    const real lo = (real)bi.lo, hi = (real)bi.hi;
    long long nGen = prm.maxFE / P - 1;
    if (nGen < 0) nGen = 0;

    const size_t n = (size_t)P * D;
    real *d_pop = nullptr, *d_trial = nullptr, *d_shift = nullptr;
    double* d_fit = nullptr;
    DERng* d_rng = nullptr;
    CUDA_CHECK(cudaMalloc(&d_rng, (size_t)P * sizeof(DERng)));
    CUDA_CHECK(cudaMalloc(&d_pop,   n * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_trial, n * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_fit,   (size_t)P * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_shift, (size_t)D * sizeof(real)));
    CUDA_CHECK(cudaMemcpy(d_shift, shift.data(), (size_t)D * sizeof(real), cudaMemcpyHostToDevice));

    // Timed scope = device initialisation + generations (allocations and copies
    // excluded), the same scope as the PSO GPU measurements.
    cudaEvent_t t0, t1;
    CUDA_CHECK(cudaEventCreate(&t0));
    CUDA_CHECK(cudaEventCreate(&t1));

    const int threads = 128;
    const int blocks  = (P + threads - 1) / threads;

    CUDA_CHECK(cudaEventRecord(t0));
    de_init_kernel<<<blocks, threads>>>(d_pop, d_fit, P, D, lo, hi, prm.func, d_shift, prm.seed, d_rng);
    CUDA_CHECK(cudaGetLastError());
    for (long long g = 0; g < nGen; g++) {
        de_trial_kernel<<<blocks, threads>>>(d_pop, d_trial, P, D, lo, hi, prm.func, d_shift,
                                             prm.F, prm.CR, d_rng);
        CUDA_CHECK(cudaGetLastError());
        de_select_kernel<<<blocks, threads>>>(d_pop, d_trial, d_fit, P, D, prm.func, d_shift);
        CUDA_CHECK(cudaGetLastError());
    }
    CUDA_CHECK(cudaEventRecord(t1));
    CUDA_CHECK(cudaEventSynchronize(t1));
    float ms = 0.0f;
    CUDA_CHECK(cudaEventElapsedTime(&ms, t0, t1));
    CUDA_CHECK(cudaEventDestroy(t0));
    CUDA_CHECK(cudaEventDestroy(t1));

    std::vector<real>   pop(n);
    std::vector<double> fit(P);
    CUDA_CHECK(cudaMemcpy(pop.data(), d_pop, n * sizeof(real), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(fit.data(), d_fit, (size_t)P * sizeof(double), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaFree(d_rng));
    CUDA_CHECK(cudaFree(d_pop));
    CUDA_CHECK(cudaFree(d_trial));
    CUDA_CHECK(cudaFree(d_fit));
    CUDA_CHECK(cudaFree(d_shift));

    int b = 0;
    for (int i = 1; i < P; i++) if (fit[i] < fit[b]) b = i;

    DEResult r;
    r.bestFit = fit[b];
    r.gBest.assign(pop.begin() + (size_t)b * D, pop.begin() + (size_t)(b + 1) * D);
    r.timeMs  = (double)ms;
    r.gens    = (int)nGen;
    r.fe      = (long long)P * (1 + nGen);
    return r;
}
