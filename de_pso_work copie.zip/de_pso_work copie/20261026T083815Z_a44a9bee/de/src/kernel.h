#pragma once
// ============================================================================
//  Massively parallel PSO (CUDA) - benchmark protocol of the M2 project
//  Objective functions : see bench_info() / fitness() below
// ============================================================================
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#ifdef __CUDACC__
  #define HD __host__ __device__
#else
  #define HD
#endif

// Precision of the swarm state. The fitness is ALWAYS accumulated in double
// (needed to reach errors ~1e-8 around biases such as -450).
// Compile with -DUSE_FLOAT for a pure single-precision swarm.
#ifdef USE_FLOAT
typedef float  real;
#else
typedef double real;
#endif

// ---------------------------------------------------------------------------
// Objective functions (same numbering as the original code)
//   0 : Levy                  (extra, not in the official protocol)
//   1 : Shifted Rastrigin     [-5, 5]^D        f* = -330
//   2 : Shifted Rosenbrock    [-100, 100]^D    f* =  390
//   3 : Shifted Griewank      [-600, 600]^D    f* = -180
//   4 : Shifted Sphere        [-100, 100]^D    f* = -450
// ---------------------------------------------------------------------------
enum ObjFunc { F_LEVY = 0, F_RASTRIGIN = 1, F_ROSENBROCK = 2, F_GRIEWANK = 3, F_SPHERE = 4 };

HD inline double f_bias(int func)
{
    switch (func) {
        case F_RASTRIGIN:  return -330.0;
        case F_ROSENBROCK: return  390.0;
        case F_GRIEWANK:   return -180.0;
        case F_SPHERE:     return -450.0;
        default:           return 0.0;
    }
}

// x[k * stride] is the k-th coordinate (stride = 1 on the host, stride = P on
// the GPU because the swarm is stored coordinate-major for coalesced access).
// o = shift vector (ignored by Levy).  One single implementation for CPU+GPU.
HD inline double fitness(const real* x, int stride, int D, int func, const real* o)
{
    const double PI = 3.14159265358979323846;
    double res = 0.0;

    switch (func) {
    case F_LEVY: {
        double w1 = 1.0 + ((double)x[0] - 1.0) / 4.0;
        double s  = sin(PI * w1);
        res = s * s;
        for (int i = 0; i < D - 1; i++) {
            double wi = 1.0 + ((double)x[i * stride] - 1.0) / 4.0;
            double t  = sin(PI * wi + 1.0);
            res += (wi - 1.0) * (wi - 1.0) * (1.0 + 10.0 * t * t);
        }
        double wd = 1.0 + ((double)x[(D - 1) * stride] - 1.0) / 4.0;
        double sd = sin(2.0 * PI * wd);
        res += (wd - 1.0) * (wd - 1.0) * (1.0 + sd * sd);
        break;
    }
    case F_RASTRIGIN: {
        for (int i = 0; i < D; i++) {
            double z = (double)x[i * stride] - (double)o[i];
            res += z * z - 10.0 * cos(2.0 * PI * z) + 10.0;
        }
        break;
    }
    case F_ROSENBROCK: {
        for (int i = 0; i < D - 1; i++) {
            double zi  = (double)x[i * stride]       - (double)o[i]     + 1.0;
            double zi1 = (double)x[(i + 1) * stride] - (double)o[i + 1] + 1.0;
            double a = zi * zi - zi1;
            double b = zi - 1.0;
            res += 100.0 * a * a + b * b;
        }
        break;
    }
    case F_GRIEWANK: {
        double sum = 0.0, prod = 1.0;          // prod MUST start at 1 (was 0 in v1)
        for (int i = 0; i < D; i++) {
            double z = (double)x[i * stride] - (double)o[i];
            sum  += z * z / 4000.0;
            prod *= cos(z / sqrt((double)(i + 1)));
        }
        res = sum - prod + 1.0;
        break;
    }
    case F_SPHERE: {
        for (int i = 0; i < D; i++) {
            double z = (double)x[i * stride] - (double)o[i];
            res += z * z;
        }
        break;
    }
    }
    return res + f_bias(func);
}

// ---------------------------------------------------------------------------
// Host-side helpers (kernel.cpp)
// ---------------------------------------------------------------------------
struct BenchInfo { const char* name; double lo, hi, bias; };
BenchInfo bench_info(int func);

// mode : "zero" | "rand" | "file:<path>"   (file = CEC2005 shift vector, first D values)
bool   make_shift(int func, int dim, const std::string& mode, std::vector<real>& o);
double host_fitness(const std::vector<real>& x, int func, const std::vector<real>& o);

// ---------------------------------------------------------------------------
// PSO (kernel.cu)
// ---------------------------------------------------------------------------
struct PSOParams {
    int       func   = F_SPHERE;
    int       dim    = 10;
    int       pop    = 50;                 // 2 .. 1024
    long long maxFE  = 100000;             // protocol : 10^4 * dim
    double    wMax   = 0.9, wMin = 0.4;    // inertia, linearly decreasing
    double    c1     = 2.0,  c2   = 2.0;
    double    vmaxFrac = 0.2;              // |v| <= vmaxFrac * (hi - lo)
    unsigned long long seed = 1234ULL;
};

struct PSOResult {
    double            bestFit = 0.0;
    double            timeMs  = 0.0;       // GPU time measured with cudaEvent
    long long         fe      = 0;         // function evaluations really used
    int               iters   = 0;
    std::vector<real> gBest;
};

PSOResult cuda_pso(const PSOParams& prm, const std::vector<real>& shift);   // kernel.cu (GPU)
PSOResult seq_pso (const PSOParams& prm, const std::vector<real>& shift);   // pso_seq.cpp (CPU, 1 thread)
