#pragma once
#include "kernel.h"
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <limits>

template<class Params, class Run>
int campaign_main(int argc, char** argv, int first, int min_pop, bool gpu, unsigned long long stream_id, Params prm, Run run) {
    try {
        if (argc != first + 4 && argc != first + 9)
            throw std::runtime_error("Arguments: dim pop func seed [runs warm_min warm_seconds warm_max warm_seed]");
        prm.dim = std::stoi(argv[first]); prm.pop = std::stoi(argv[first+1]);
        prm.func = std::stoi(argv[first+2]); prm.seed = std::stoull(argv[first+3]);
        prm.maxFE = 10000LL * prm.dim;
        int runs = 1, warm_min = 0, warm_max = 0;
        double warm_seconds = 0;
        unsigned long long warm_seed = 910000;
        if (argc == first+9) {
            runs = std::stoi(argv[first+4]); warm_min = std::stoi(argv[first+5]);
            warm_seconds = std::stod(argv[first+6]); warm_max = std::stoi(argv[first+7]);
            warm_seed = std::stoull(argv[first+8]);
        }
        if (prm.dim < 1 || prm.pop < min_pop || prm.pop > prm.maxFE ||
            prm.func < 1 || prm.func > 4 || runs < 1 || warm_min < 0 || warm_max < warm_min ||
            !std::isfinite(warm_seconds) || warm_seconds < 0 ||
            (warm_seconds > 0 && warm_max < 1) || (!gpu && (warm_min || warm_seconds)))
            throw std::runtime_error("Invalid campaign parameters");
        const auto seed0 = prm.seed;
        if (seed0 > std::numeric_limits<unsigned long long>::max() - (unsigned)runs ||
            warm_seed > std::numeric_limits<unsigned long long>::max() - (unsigned)warm_max)
            throw std::runtime_error("Seed overflow");
        if (warm_max && warm_seed < seed0 + runs && seed0 < warm_seed + warm_max)
            throw std::runtime_error("Warm-up and measurement seeds overlap");
        std::vector<real> shift;
        if (!make_shift(prm.func, prm.dim, "rand", shift)) throw std::runtime_error("Shift failed");
        auto execute = [&](const char* phase, int index, unsigned long long seed) {
            // Domain-separated engine streams; the external seed identifies the run.
            // All arithmetic is uint64_t modulo 2^64 (SplitMix64 finalizer).
            unsigned long long z = seed + 0x9e3779b97f4a7c15ULL * (stream_id+1);
            z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
            z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
            prm.seed = z ^ (z >> 31);
            auto res = run(prm, shift);
            const double host = host_fitness(res.gBest, prm.func, shift);
            const double tol = 1e-9 * (1.0 + std::fabs(host));
            const auto expected_fe = (prm.maxFE / prm.pop) * prm.pop;
            if (!std::isfinite(res.bestFit) || !std::isfinite(host) ||
                !std::isfinite(res.timeMs) || res.timeMs <= 0 ||
                std::fabs(host-res.bestFit) > tol || res.fe != expected_fe)
                throw std::runtime_error("Invalid fitness, timing, host recomputation or FE count");
            printf("%s: %d | Seed: %llu | EngineSeed: %llu | Best Fitness: %.17e | FEs: %lld | Time: %.6f ms\n",
                   phase, index, seed, prm.seed, res.bestFit, res.fe, res.timeMs);
            fflush(stdout);
            return res.timeMs;
        };
        int warmed = 0; double warm_ms = 0;
        while (warmed < warm_max && (warmed < warm_min || warm_ms < 1000.0 * warm_seconds)) {
            warm_ms += execute("Warmup", warmed, warm_seed + warmed); ++warmed;
        }
        printf("WarmupTarget: %d\n", (warmed >= warm_min && warm_ms >= warm_seconds*1000.0) ? 1 : 0);
        for (int r=0; r<runs; ++r) execute("Measured", r, seed0 + r);
        return 0;
    } catch (const std::exception& exc) {
        std::cerr << exc.what() << "\n"; return 1;
    }
}
