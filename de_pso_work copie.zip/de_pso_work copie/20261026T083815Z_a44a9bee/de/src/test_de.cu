#define DE_TESTING
#include "de.cu"
#include <algorithm>
#include <vector>
#include <stdexcept>
__global__ void check_donors(int* invalid) {
    int i=threadIdx.x; DERng st;curand_init(1234,i,0,&st);DeviceIndex draw{&st};
    for(int k=0;k<1000;k++){int a,b,c;de_donors(draw,4,i,a,b,c);
      if(a==i||b==i||c==i||a==b||a==c||b==c)atomicAdd(invalid,1);}
}
int main() {
    constexpr int P=4,D=3;std::vector<real> pop={-3,1,2, 4,-2,1, 2,3,-1, -1,4,3},trial(P*D),expected(P*D),shift(D,0);
    std::vector<double> fit(P),expected_fit(P);
    DERng* rng;
    real *dp,*dt,*ds;double* df;int* bad;
    CUDA_CHECK(cudaMalloc(&dp,P*D*sizeof(real)));CUDA_CHECK(cudaMalloc(&dt,P*D*sizeof(real)));
    CUDA_CHECK(cudaMalloc(&ds,D*sizeof(real)));CUDA_CHECK(cudaMalloc(&df,P*sizeof(double)));
    CUDA_CHECK(cudaMalloc(&rng,P*sizeof(DERng)));CUDA_CHECK(cudaMalloc(&bad,sizeof(int)));
    CUDA_CHECK(cudaMemset(bad,0,sizeof(int)));check_donors<<<1,P>>>(bad);
    int invalid;CUDA_CHECK(cudaMemcpy(&invalid,bad,sizeof(int),cudaMemcpyDeviceToHost));
    if(invalid)throw std::runtime_error("GPU donor exclusion failed");
    CUDA_CHECK(cudaMemcpy(ds,shift.data(),D*sizeof(real),cudaMemcpyHostToDevice));
    de_init_kernel<<<1,P>>>(dp,df,P,D,-5,5,4,ds,1234,rng);
    // Known population, RNG states after initialisation, separate immutable source.
    CUDA_CHECK(cudaMemcpy(dp,pop.data(),P*D*sizeof(real),cudaMemcpyHostToDevice));
    for(int i=0;i<P;i++)fit[i]=fitness(&pop[i*D],1,D,4,shift.data());
    CUDA_CHECK(cudaMemcpy(df,fit.data(),P*sizeof(double),cudaMemcpyHostToDevice));
    de_trial_kernel<<<1,P>>>(dp,dt,P,D,-5,5,4,ds,0.5,0.3,rng);
    CUDA_CHECK(cudaMemcpy(trial.data(),dt,P*D*sizeof(real),cudaMemcpyDeviceToHost));
    std::vector<real> unchanged(P*D);CUDA_CHECK(cudaMemcpy(unchanged.data(),dp,P*D*sizeof(real),cudaMemcpyDeviceToHost));
    if(unchanged!=pop)throw std::runtime_error("Trial kernel modified source generation");
    expected=pop;expected_fit=fit;
    for(int i=0;i<P;i++) {
      double f=fitness(&trial[i*D],1,D,4,shift.data());
      if(f<=fit[i]){expected_fit[i]=f;for(int j=0;j<D;j++)expected[i*D+j]=trial[i*D+j];}
      for(int j=0;j<D;j++)if(trial[i*D+j]<-5||trial[i*D+j]>5)throw std::runtime_error("Trial bounds");
    }
    de_select_kernel<<<1,P>>>(dp,dt,df,P,D,4,ds);
    CUDA_CHECK(cudaMemcpy(pop.data(),dp,P*D*sizeof(real),cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(fit.data(),df,P*sizeof(double),cudaMemcpyDeviceToHost));
    if(pop!=expected||fit!=expected_fit)throw std::runtime_error("CPU/GPU selection differs");
    // Replay the same fixture: Philox state progression must be reproducible.
    de_init_kernel<<<1,P>>>(dp,df,P,D,-5,5,4,ds,1234,rng);
    CUDA_CHECK(cudaMemcpy(dp,unchanged.data(),P*D*sizeof(real),cudaMemcpyHostToDevice));
    de_trial_kernel<<<1,P>>>(dp,dt,P,D,-5,5,4,ds,0.5,0.3,rng);
    CUDA_CHECK(cudaMemcpy(expected.data(),dt,P*D*sizeof(real),cudaMemcpyDeviceToHost));
    if(expected!=trial)throw std::runtime_error("GPU replay differs");
    // Identical explicit donor/crossover tape on CPU and GPU: test actual trial kernel.
    int donor_tape[P*4]={1,2,3,0, 0,2,3,1, 0,1,3,2, 0,1,2,0};
    double uniforms[P*D]={0.9,0.8,0.1, 0.2,0.8,0.9, 0.9,0.2,0.8, 0.9,0.1,0.8};
    int* dd;double* du;
    CUDA_CHECK(cudaMalloc(&dd,sizeof(donor_tape)));CUDA_CHECK(cudaMalloc(&du,sizeof(uniforms)));
    CUDA_CHECK(cudaMemcpy(dd,donor_tape,sizeof(donor_tape),cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(du,uniforms,sizeof(uniforms),cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dp,unchanged.data(),P*D*sizeof(real),cudaMemcpyHostToDevice));
    de_trial_kernel<<<1,P>>>(dp,dt,P,D,-5,5,4,ds,0.5,0.3,rng,dd,du);
    CUDA_CHECK(cudaMemcpy(trial.data(),dt,P*D*sizeof(real),cudaMemcpyDeviceToHost));
    for(int i=0;i<P;i++)for(int j=0;j<D;j++) {
        int a=donor_tape[i*4],b=donor_tape[i*4+1],c=donor_tape[i*4+2],forced=donor_tape[i*4+3];
        bool crossed=uniforms[i*D+j]<=0.3||j==forced;
        double v=crossed ? unchanged[a*D+j]+0.5*(unchanged[b*D+j]-unchanged[c*D+j]) : unchanged[i*D+j];
        v=std::max(-5.0,std::min(5.0,v));
        if(trial[i*D+j]!=v)throw std::runtime_error("CPU/GPU fixed-tape mutation/crossover differs");
    }
    CUDA_CHECK(cudaFree(dd));CUDA_CHECK(cudaFree(du));
    CUDA_CHECK(cudaFree(dp));CUDA_CHECK(cudaFree(dt));CUDA_CHECK(cudaFree(ds));CUDA_CHECK(cudaFree(df));
    CUDA_CHECK(cudaFree(rng));CUDA_CHECK(cudaFree(bad));
    puts("DE CUDA: donor exclusions, immutable source, CPU/GPU fixed-tape mutation/crossover and selection, bounds and replay OK");
}
