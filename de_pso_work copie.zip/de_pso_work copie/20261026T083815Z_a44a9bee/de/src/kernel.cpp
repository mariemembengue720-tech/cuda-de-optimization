#include "kernel.h"
#include <chrono>
#include <fstream>
#include <random>

BenchInfo bench_info(int func)
{
    switch (func) {
        case F_LEVY:       return { "Levy",       -10.0,   10.0,    0.0 };
        case F_RASTRIGIN:  return { "Rastrigin",   -5.0,    5.0, -330.0 };
        case F_ROSENBROCK: return { "Rosenbrock", -100.0,  100.0,  390.0 };
        case F_GRIEWANK:   return { "Griewank",   -600.0,  600.0, -180.0 };
        case F_SPHERE:     return { "Sphere",     -100.0,  100.0, -450.0 };
        default:           return { "?", 0, 0, 0 };
    }
}

// Shift vector o :  z = x - o, optimum at x* = o, f(x*) = bias.
//  "zero"       : o = 0 (behaviour of the original code)
//  "rand"       : reproducible o_i in [0.8*lo, 0.8*hi] (fixed seed, prefix-stable in dim)
//  "file:<path>": first `dim` numbers of a CEC2005 data file (e.g. sphere_func_data.txt)
bool make_shift(int func, int dim, const std::string& mode, std::vector<real>& o)
{
    o.assign(dim, (real)0);
    if (func == F_LEVY || mode == "zero") return true;

    BenchInfo b = bench_info(func);
    if (mode == "rand") {
        std::mt19937_64 gen(20261027ULL + (unsigned)func);
        std::uniform_real_distribution<double> U(0.8 * b.lo, 0.8 * b.hi);
        for (int i = 0; i < dim; i++) o[i] = (real)U(gen);
        return true;
    }
    if (mode.rfind("file:", 0) == 0) {
        std::ifstream f(mode.substr(5));
        if (!f) { fprintf(stderr, "cannot open shift file %s\n", mode.c_str() + 5); return false; }
        double v;
        for (int i = 0; i < dim; i++) {
            if (!(f >> v)) { fprintf(stderr, "shift file has fewer than %d values\n", dim); return false; }
            o[i] = (real)v;
        }
        return true;
    }
    fprintf(stderr, "unknown shift mode '%s'\n", mode.c_str());
    return false;
}

// Same code as the GPU one (kernel.h) -> used to double-check the GPU result.
double host_fitness(const std::vector<real>& x, int func, const std::vector<real>& o)
{
    return fitness(x.data(), 1, (int)x.size(), func, o.data());
}


// ============================================================================
//  Sequential PSO (CPU, 1 thread) - reference implementation, compiled with the
//  rest of kernel.cpp (build with -DSEQUENTIAL to use it from main.cpp).
//  Same algorithm, parameters, budget and output as the CUDA version (kernel.cu):
//    - synchronous PSO : gBest is updated once per generation, after all pBest
//    - independent r1, r2 per particle AND per dimension
//    - inertia decreasing linearly wMax -> wMin, velocity and position clamping
//    - FEs = P * (1 + nIter) <= MaxFEs
//  Only the RNG differs (mt19937_64 here, cuRAND Philox on the GPU): results are
//  not bit-identical; statistical agreement must be assessed experimentally.
//  Memory layout is particle-major (p*D + d), the cache-friendly one on a CPU.
// ============================================================================
PSOResult seq_pso(const PSOParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 2 || D < 1 || (int)shift.size() < D) {
        fprintf(stderr, "seq_pso: invalid parameters (pop >= 2, dim >= 1)\n");
        exit(1);
    }
    const BenchInfo bi = bench_info(prm.func);
    const size_t n = (size_t)P * D;
    const real lo   = (real)bi.lo, hi = (real)bi.hi;
    const real vmax = (real)(prm.vmaxFrac * (bi.hi - bi.lo));
    const real c1 = (real)prm.c1, c2 = (real)prm.c2;

    long long nIter = prm.maxFE / P - 1;           // initial evaluation costs P FEs
    if (nIter < 0) nIter = 0;

    std::mt19937_64 gen(prm.seed);
    std::uniform_real_distribution<real> U01((real)0, (real)1);

    std::vector<real>   pos(n), vel(n, (real)0), pbest(n), gbest(D, (real)0);
    std::vector<double> pfit(P, 1.0e300);
    double gfit = 1.0e300;

    // evaluation + pBest update (kernel E on the GPU)
    auto evaluate = [&]() {
        for (int p = 0; p < P; p++) {
            double f = fitness(&pos[(size_t)p * D], 1, D, prm.func, shift.data());
            if (f < pfit[p]) {
                pfit[p] = f;
                for (int d = 0; d < D; d++) pbest[(size_t)p * D + d] = pos[(size_t)p * D + d];
            }
        }
    };
    // gBest = argmin of pBest fitness (kernel G on the GPU)
    auto reduce_gbest = [&]() {
        int b = 0;
        for (int p = 1; p < P; p++) if (pfit[p] < pfit[b]) b = p;
        if (pfit[b] < gfit) {
            gfit = pfit[b];
            for (int d = 0; d < D; d++) gbest[d] = pbest[(size_t)b * D + d];
        }
    };

    auto t0 = std::chrono::steady_clock::now();

    // initialisation (kernel I)
    for (size_t e = 0; e < n; e++) {
        pos[e]   = lo + (hi - lo) * U01(gen);
        pbest[e] = pos[e];
    }
    evaluate();
    reduce_gbest();

    // main loop
    for (long long it = 0; it < nIter; it++) {
        const real w = (real)((nIter > 1)
            ? prm.wMax - (prm.wMax - prm.wMin) * (double)it / (double)(nIter - 1)
            : prm.wMax);

        // velocity & position update (kernel U)
        for (int p = 0; p < P; p++) {
            for (int d = 0; d < D; d++) {
                const size_t e = (size_t)p * D + d;
                const real r1 = U01(gen), r2 = U01(gen);
                real x = pos[e];
                real v = w * vel[e] + c1 * r1 * (pbest[e] - x) + c2 * r2 * (gbest[d] - x);
                if (v >  vmax) v =  vmax;
                if (v < -vmax) v = -vmax;
                x += v;
                if (x < lo)      { x = lo; v = (real)0; }
                else if (x > hi) { x = hi; v = (real)0; }
                vel[e] = v;
                pos[e] = x;
            }
        }
        evaluate();
        reduce_gbest();
    }

    auto t1 = std::chrono::steady_clock::now();

    PSOResult r;
    r.bestFit = gfit;
    r.gBest   = gbest;
    r.timeMs  = std::chrono::duration<double, std::milli>(t1 - t0).count();
    r.iters   = (int)nIter;
    r.fe      = (long long)P * (1 + nIter);
    return r;
}
