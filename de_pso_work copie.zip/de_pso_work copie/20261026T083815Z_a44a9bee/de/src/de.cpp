#include "de.h"
#include "de_ops.h"
#include <chrono>
#include <random>

// Sequential DE (CPU, 1 thread), same structure and timing scope as seq_pso()
// in kernel.cpp: steady_clock over initialisation + generations.
DEResult seq_de(const DEParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 4 || D < 1 || (int)shift.size() < D) {
        fprintf(stderr, "seq_de: invalid parameters (pop >= 4, dim >= 1, shift size >= dim)\n");
        exit(1);
    }
    const BenchInfo bi = bench_info(prm.func);
    const real lo = (real)bi.lo, hi = (real)bi.hi;
    const real F = (real)prm.F, CR = (real)prm.CR;

    long long nGen = prm.maxFE / P - 1;          // initialisation costs P FEs
    if (nGen < 0) nGen = 0;

    std::mt19937_64 gen(prm.seed);
    std::uniform_real_distribution<double> U01(0.0, 1.0);
    // Portable integer draw: mt19937_64 output is standardised, unlike rand().
    auto idx = [&](int n) { return (int)(gen() % (unsigned long long)n); };

    const size_t n = (size_t)P * D;
    std::vector<real>   pop(n), trial(n), gbest(D, (real)0);
    std::vector<double> fit(P, 1.0e300);

    auto t0 = std::chrono::steady_clock::now();

    // initialisation: uniform in the bounds, one evaluation per individual
    for (size_t e = 0; e < n; e++) pop[e] = lo + (hi - lo) * (real)U01(gen);
    for (int i = 0; i < P; i++) fit[i] = fitness(&pop[(size_t)i * D], 1, D, prm.func, shift.data());

    for (long long g = 0; g < nGen; g++) {
        for (int i = 0; i < P; i++) {
            // DE/rand/1: three partners distinct from i and from each other
            int r1, r2, r3;
            de_donors(idx, P, i, r1, r2, r3);
            const int jr = idx(D);               // at least one crossed gene

            // Read only generation g; replacements happen after ALL trials exist.
            for (int j = 0; j < D; j++) {
                const bool cross = U01(gen) <= (double)CR || j == jr;
                trial[(size_t)i * D + j] = de_coordinate(pop.data(), D, i, r1, r2, r3,
                                                        j, cross, F, lo, hi);
            }
        }
        for (int i = 0; i < P; i++) {
            const double tf = fitness(&trial[(size_t)i * D], 1, D, prm.func, shift.data());
            if (tf <= fit[i]) {
                for (int j = 0; j < D; j++) pop[(size_t)i * D + j] = trial[(size_t)i * D + j];
                fit[i] = tf;
            }
        }
    }

    auto t1 = std::chrono::steady_clock::now();

    int b = 0;
    for (int i = 1; i < P; i++) if (fit[i] < fit[b]) b = i;
    for (int j = 0; j < D; j++) gbest[j] = pop[(size_t)b * D + j];

    DEResult r;
    r.bestFit = fit[b];
    r.gBest   = gbest;
    r.timeMs  = std::chrono::duration<double, std::milli>(t1 - t0).count();
    r.gens    = (int)nGen;
    r.fe      = (long long)P * (1 + nGen);
    return r;
}
