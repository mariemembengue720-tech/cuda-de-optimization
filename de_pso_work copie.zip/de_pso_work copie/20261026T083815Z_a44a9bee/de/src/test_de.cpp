#include "de.h"
#include "de_ops.h"
#include <random>
#include <stdexcept>
#include <algorithm>
#define REQUIRE(x) do { if (!(x)) throw std::runtime_error(#x); } while(0)
// Independent implementation: copy old population, fill next, swap once per generation.
DEResult oracle(DEParams prm, const std::vector<real>& shift) {
    const int P=prm.pop,D=prm.dim; auto b=bench_info(prm.func);
    std::mt19937_64 gen(prm.seed); std::uniform_real_distribution<double> u(0,1);
    auto idx=[&](int n){return int(gen() % (unsigned long long)n);};
    std::vector<real> current(P*D),next(P*D),candidate(D);
    std::vector<double> scores(P);
    for(auto& x:current)x=b.lo+(b.hi-b.lo)*u(gen);
    for(int i=0;i<P;i++)scores[i]=fitness(&current[i*D],1,D,prm.func,shift.data());
    double previous=*std::min_element(scores.begin(),scores.end());
    for(long long g=1;g<prm.maxFE/P;g++) {
        next=current;
        for(int i=0;i<P;i++) {
            int a,c,d; do {a=idx(P);}while(a==i);
            do {c=idx(P);}while(c==i||c==a);
            do {d=idx(P);}while(d==i||d==a||d==c);
            int forced=idx(D);
            for(int j=0;j<D;j++) {
                bool cross=u(gen)<=prm.CR||j==forced;
                double value=cross ? current[a*D+j]+prm.F*(current[c*D+j]-current[d*D+j]) : current[i*D+j];
                candidate[j]=std::max(b.lo,std::min(b.hi,value));
            }
            double f=fitness(candidate.data(),1,D,prm.func,shift.data());
            if(f<=scores[i]) {scores[i]=f;std::copy(candidate.begin(),candidate.end(),next.begin()+i*D);}
        }
        current.swap(next);
        double now=*std::min_element(scores.begin(),scores.end()); REQUIRE(now<=previous); previous=now;
    }
    int best=std::min_element(scores.begin(),scores.end())-scores.begin();
    DEResult r;r.bestFit=scores[best];r.gBest.assign(current.begin()+best*D,current.begin()+(best+1)*D);return r;
}
int main() {
    std::mt19937_64 gen(17);auto draw=[&](int n){return int(gen()%(unsigned)n);};
    for(int P:{4,5,50,500})for(int i=0;i<P;i++)for(int k=0;k<100;k++) {
        int a,b,c;de_donors(draw,P,i,a,b,c);
        REQUIRE(a!=i&&b!=i&&c!=i&&a!=b&&a!=c&&b!=c);
    }
    int cases=0;
    for(int f:{1,2,3,4})for(int D:{1,3,10})for(int P:{4,7,50})for(int seed:{1234,1235}) {
        DEParams p;p.func=f;p.dim=D;p.pop=P;p.seed=seed;p.maxFE=P*9+P/2;
        std::vector<real> shift;REQUIRE(make_shift(f,D,"rand",shift));
        REQUIRE(std::fabs(host_fitness(shift,f,shift)-f_bias(f))<1e-10);
        auto expected=oracle(p,shift),actual=seq_de(p,shift);
        REQUIRE(actual.bestFit==expected.bestFit);REQUIRE(actual.gBest==expected.gBest);
        REQUIRE(actual.fe==P*9);REQUIRE(actual.gens==8);
        auto bounds=bench_info(f);for(auto x:actual.gBest)REQUIRE(x>=bounds.lo&&x<=bounds.hi);
        ++cases;
    }
    puts("DE CPU: 72 cases, donor exclusions, frozen generations, bounds, optimum and FE accounting OK");
}
