#pragma once
#include "kernel.h"
template<class Draw> HD inline void de_donors(Draw& draw, int P, int i, int& a, int& b, int& c) {
    do { a = draw(P); } while (a == i);
    do { b = draw(P); } while (b == i || b == a);
    do { c = draw(P); } while (c == i || c == a || c == b);
}
HD inline real de_coordinate(const real* pop, int D, int i, int a, int b, int c,
                              int j, bool cross, real F, real lo, real hi) {
    if (!cross) return pop[(size_t)i * D + j];
    real v = pop[(size_t)a * D + j] + F * (pop[(size_t)b * D + j] - pop[(size_t)c * D + j]);
    return v < lo ? lo : (v > hi ? hi : v);
}
