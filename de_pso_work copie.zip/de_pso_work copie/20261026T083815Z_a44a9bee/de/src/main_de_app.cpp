#include "de.h"
#include "campaign.h"
int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "First argument: cpu|gpu\n"); return 1; }
    const std::string mode(argv[1]);
    if (mode == "cpu") return campaign_main(argc, argv, 2, 4, false, 0, DEParams{}, seq_de);
#ifndef DE_CPU_ONLY
    if (mode == "gpu") return campaign_main(argc, argv, 2, 4, true, 1, DEParams{}, cuda_de);
#endif
    fprintf(stderr, "Unsupported mode\n"); return 1;
}
