#include "kernel.h"
#include "campaign.h"
int main(int argc, char** argv) {
#ifdef PSO_CPU_ONLY
    return campaign_main(argc, argv, 1, 2, false, 2, PSOParams{}, seq_pso);
#else
    return campaign_main(argc, argv, 1, 2, true, 3, PSOParams{}, cuda_pso);
#endif
}
