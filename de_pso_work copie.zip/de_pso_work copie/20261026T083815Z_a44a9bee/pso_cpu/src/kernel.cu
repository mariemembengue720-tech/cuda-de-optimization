#include <cuda_runtime.h>
#include <curand_kernel.h>
#include "kernel.h"

#define CUDA_CHECK(call)                                                        \
    do {                                                                        \
        cudaError_t e_ = (call);                                                \
        if (e_ != cudaSuccess) {                                                \
            fprintf(stderr, "CUDA error %s:%d : %s\n", __FILE__, __LINE__,      \
                    cudaGetErrorString(e_));                                    \
            exit(1);                                                            \
        }                                                                       \
    } while (0)

#define INF_FIT 1.0e300
static const int TPB = 128;                       // threads per block

typedef curandStatePhilox4_32_10_t RngState;

// Swarm layout is coordinate-major (SoA): element (particle p, dim d) lives at
// d * P + p  ->  one thread per particle gives fully coalesced accesses.

__device__ __forceinline__ real urand(RngState* s)
{
#ifdef USE_FLOAT
    return curand_uniform(s);
#else
    return curand_uniform_double(s);
#endif
}

// ---- 1. initialisation : one thread per (particle, dimension) --------------
__global__ void k_init(real* pos, real* vel, real* pbest, double* pfit,
                       RngState* rng, int P, int D, real lo, real hi,
                       unsigned long long seed)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= P * D) return;

    RngState st;
    curand_init(seed, (unsigned long long)e, 0ULL, &st);
    real x = lo + (hi - lo) * urand(&st);
    pos[e]   = x;
    pbest[e] = x;
    vel[e]   = (real)0;
    rng[e]   = st;
    if (e < P) pfit[e] = INF_FIT;
}

// ---- 2. velocity / position update : one thread per element ----------------
// independent r1, r2 for every particle AND every dimension (standard PSO)
__global__ void k_update(real* pos, real* vel, const real* pbest,
                         const real* gbest, RngState* rng, int P, int D,
                         real lo, real hi, real w, real c1, real c2, real vmax)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= P * D) return;
    int d = e / P;

    RngState st = rng[e];
    real r1 = urand(&st);
    real r2 = urand(&st);
    rng[e] = st;

    real x = pos[e];
    real v = w * vel[e] + c1 * r1 * (pbest[e] - x) + c2 * r2 * (gbest[d] - x);
    v = fmax(-vmax, fmin(vmax, v));               // velocity clamping
    x += v;
    if (x < lo)      { x = lo; v = (real)0; }     // position clamping
    else if (x > hi) { x = hi; v = (real)0; }
    vel[e] = v;
    pos[e] = x;
}

// ---- 3. evaluation + pBest update : one thread per particle ----------------
// pBest fitness is stored (pfit) -> never recomputed.
__global__ void k_eval(const real* pos, real* pbest, double* pfit, int P, int D,
                       int func, const real* shift)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= P) return;

    double f = fitness(pos + p, P, D, func, shift);
    if (f < pfit[p]) {
        pfit[p] = f;
        for (int d = 0; d < D; d++) pbest[(size_t)d * P + p] = pos[(size_t)d * P + p];
    }
}

// ---- 4. gBest : argmin reduction over pBest fitness, entirely on the GPU ----
// launched with ONE block whose size is a power of two >= P (P <= 1024)
__global__ void k_gbest(const real* pbest, const double* pfit, real* gbest,
                        double* gfit, int P, int D)
{
    __shared__ double sv[1024];
    __shared__ int    si[1024];
    int t = threadIdx.x;

    sv[t] = (t < P) ? pfit[t] : INF_FIT;
    si[t] = t;
    __syncthreads();

    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (t < s && sv[t + s] < sv[t]) { sv[t] = sv[t + s]; si[t] = si[t + s]; }
        __syncthreads();
    }

    const double best = sv[0];
    const int    bi   = si[0];
    const double old  = *gfit;       // read by everybody BEFORE thread 0 writes
    __syncthreads();

    if (best < old) {
        for (int d = t; d < D; d += blockDim.x) gbest[d] = pbest[(size_t)d * P + bi];
        if (t == 0) *gfit = best;
    }
}

// ---------------------------------------------------------------------------
PSOResult cuda_pso(const PSOParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 2 || P > 1024 || D < 1 || (int)shift.size() < D) {
        fprintf(stderr, "cuda_pso: invalid parameters (pop in [2,1024], dim>=1)\n");
        exit(1);
    }
    const BenchInfo bi = bench_info(prm.func);
    const size_t n = (size_t)P * D;

    static bool warm = false;
    if (!warm) { CUDA_CHECK(cudaFree(0)); warm = true; }   // create context

    real *d_pos, *d_vel, *d_pbest, *d_gbest, *d_shift;
    double *d_pfit, *d_gfit;
    RngState* d_rng;
    CUDA_CHECK(cudaMalloc(&d_pos,   n * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_vel,   n * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_pbest, n * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_gbest, D * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_shift, D * sizeof(real)));
    CUDA_CHECK(cudaMalloc(&d_pfit,  P * sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_gfit,  sizeof(double)));
    CUDA_CHECK(cudaMalloc(&d_rng,   n * sizeof(RngState)));

    CUDA_CHECK(cudaMemcpy(d_shift, shift.data(), D * sizeof(real), cudaMemcpyHostToDevice));
    const double inf = INF_FIT;
    CUDA_CHECK(cudaMemcpy(d_gfit, &inf, sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_gbest, 0, D * sizeof(real)));

    const int blocksE = (int)((n + TPB - 1) / TPB);
    const int blocksP = (P + TPB - 1) / TPB;
    int gbThreads = 32;
    while (gbThreads < P) gbThreads <<= 1;

    const real lo   = (real)bi.lo, hi = (real)bi.hi;
    const real vmax = (real)(prm.vmaxFrac * (bi.hi - bi.lo));

    // FE budget : initial evaluation (P) + nIter * P  <=  maxFE
    long long nIter = prm.maxFE / P - 1;
    if (nIter < 0) nIter = 0;

    cudaEvent_t e0, e1;
    CUDA_CHECK(cudaEventCreate(&e0));
    CUDA_CHECK(cudaEventCreate(&e1));
    CUDA_CHECK(cudaEventRecord(e0));

    k_init<<<blocksE, TPB>>>(d_pos, d_vel, d_pbest, d_pfit, d_rng, P, D, lo, hi, prm.seed);
    k_eval<<<blocksP, TPB>>>(d_pos, d_pbest, d_pfit, P, D, prm.func, d_shift);
    k_gbest<<<1, gbThreads>>>(d_pbest, d_pfit, d_gbest, d_gfit, P, D);

    for (long long it = 0; it < nIter; it++) {
        double w = (nIter > 1) ? prm.wMax - (prm.wMax - prm.wMin) * (double)it / (double)(nIter - 1)
                               : prm.wMax;
        k_update<<<blocksE, TPB>>>(d_pos, d_vel, d_pbest, d_gbest, d_rng, P, D, lo, hi,
                                   (real)w, (real)prm.c1, (real)prm.c2, vmax);
        k_eval<<<blocksP, TPB>>>(d_pos, d_pbest, d_pfit, P, D, prm.func, d_shift);
        k_gbest<<<1, gbThreads>>>(d_pbest, d_pfit, d_gbest, d_gfit, P, D);
    }
    CUDA_CHECK(cudaGetLastError());

    CUDA_CHECK(cudaEventRecord(e1));
    CUDA_CHECK(cudaEventSynchronize(e1));        // also surfaces async kernel errors
    float ms = 0.f;
    CUDA_CHECK(cudaEventElapsedTime(&ms, e0, e1));

    PSOResult r;
    r.gBest.resize(D);
    CUDA_CHECK(cudaMemcpy(r.gBest.data(), d_gbest, D * sizeof(real), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&r.bestFit, d_gfit, sizeof(double), cudaMemcpyDeviceToHost));
    r.timeMs = ms;
    r.iters  = (int)nIter;
    r.fe     = (long long)P * (1 + nIter);

    cudaEventDestroy(e0); cudaEventDestroy(e1);
    cudaFree(d_pos); cudaFree(d_vel); cudaFree(d_pbest); cudaFree(d_gbest);
    cudaFree(d_shift); cudaFree(d_pfit); cudaFree(d_gfit); cudaFree(d_rng);
    return r;
}
