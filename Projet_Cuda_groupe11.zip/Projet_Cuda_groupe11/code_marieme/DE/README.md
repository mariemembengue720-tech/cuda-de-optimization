# Évolution différentielle DE/rand/1/bin sur CPU et GPU (CUDA)

Algorithmes : **DE-CPU** (séquentiel) et **DE-GPU** (version de base, 6 kernels : I, E, P, M, C, R).
La version optimisée DE-GPU-OPT (kernels fusionnés, deux flux) fait partie du projet complet.

| Fichier | Rôle |
|---|---|
| kernel.h | fonctions de test décalées (CEC2005), paramètres, déclarations |
| kernel.cpp | DE-CPU, vecteurs de décalage |
| kernel.cu | DE-GPU de base |
| main.cpp | programme principal : runs, moyenne/écart-type, temps, taux de succès, CSV |
| notebook_de.ipynb | notebook (Kaggle ou Colab, GPU) : compile, teste, lance le protocole, tableaux, figures, tests statistiques |

## Principe (DE/rand/1/bin, mise à jour synchrone)
Pour chaque individu : mutation `v = x_r1 + F·(x_r2 − x_r3)` (r1, r2, r3 distincts et ≠ i), croisement binomial (taux CR, au moins une coordonnée du mutant), sélection gloutonne.
F = 0,5, CR = 0,3. Budget : MaxFEs = 10⁴·D, soit ⌊MaxFEs/P⌋ − 1 générations.

## Compiler et lancer
    nvcc -O3 -std=c++17 -arch=sm_75 kernel.cu kernel.cpp main.cpp -o de
    ./de --verify
    ./de --algo de-cpu,de-gpu --func 4 --dim 50 --pop 100 --runs 10 --seed 1234
    ./de --sweep --out resultats_de.csv
Sans GPU : `g++ -O2 -std=c++17 -DNO_CUDA kernel.cpp main.cpp -o de` (DE-CPU seulement).
`--func` : 1 Rastrigin, 2 Rosenbrock, 3 Griewank, 4 Sphere.

## Notebook
Sur Kaggle : créer un dataset avec `kernel.h kernel.cpp kernel.cu main.cpp`, l'ajouter au notebook, activer le GPU, puis *Run All* (`QUICK = False` pour le protocole officiel à 10 exécutions).
