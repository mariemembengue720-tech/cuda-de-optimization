// ============================================================================
//  kernel.cu - DE-GPU de base (Fig. 1 de l'article) : kernels I, E, P, M, C, R
//   population stockee individu par individu : X[i*D + j]
//   un bloc = un individu pour l'evaluation, un thread = une coordonnee ailleurs.
//   Mise a jour synchrone (double tampon), cuRAND Philox, fitness en double.
//   Chronometrage : horloge murale entre deux cudaDeviceSynchronize(), allocations
//   et creation du contexte CUDA exclues (echauffement dans main).
// ============================================================================
#include "kernel.h"
#include <chrono>
#include <cuda_runtime.h>
#include <curand_kernel.h>

// Affiche l'erreur CUDA et arrete le programme si un appel GPU echoue.
#define CUDA_CHECK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { \
    fprintf(stderr, "CUDA error '%s' at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); exit(1); } } while (0)

// RNG = generateur aleatoire du GPU (Philox) : un "etat" par thread, donc sans conflit.
typedef curandStatePhilox4_32_10_t RNG;
// TB = nombre de threads par bloc pour les kernels simples.
static const int TB = 256;                       // threads/block of the element-wise kernels
static inline int nblk(long long n) { return (int)((n + TB - 1) / TB); }
static inline int next_pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }
static const unsigned long long SEED_X = 0x9E3779B97F4A7C15ULL;   // decorrelates RNG families

template <typename T> static T* dmalloc(size_t n) { T* p; CUDA_CHECK(cudaMalloc(&p, n * sizeof(T))); return p; }

// Chronometre (ms). On mesure entre deux cudaDeviceSynchronize pour inclure tout le travail GPU.
static double now_ms()
{
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// ===========================================================================
//  DE common : population stored individual-major  X[i*D + j]
// ===========================================================================

// ---- basic DE (Fig. 1) -----------------------------------------------------
// kernel(I) : population init + RNG states (crossover : 1 per element, indices : 1 per individual)
// DE kernel I (Init) : population aleatoire + etats aleatoires. 1 thread = 1 valeur.
__global__ void de_I(real* X, RNG* stE, RNG* stP, int n, int P, real lo, real hi, unsigned long long seed)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    RNG s; curand_init(seed, e, 0, &s);
    X[e] = lo + (hi - lo) * (real)curand_uniform_double(&s);
    stE[e] = s;
    if (e < P) { RNG q; curand_init(seed ^ SEED_X, e, 0, &q); stP[e] = q; }
}

// kernel(E) : ONE BLOCK PER INDIVIDUAL, D threads (padded to a power of two) + tree reduction
// DE kernel E (Evaluation) : UN BLOC = UN INDIVIDU. Chaque thread calcule le terme d'une coordonnee,
// puis une reduction en arbre fait la somme. (DE-GPU de base, Fig. 1 de l'article).
__global__ void de_E(const real* X, double* fit, int D, int func, const real* o)
{
    extern __shared__ double sh[];
    double* sa = sh; double* sb = sh + blockDim.x;
    const int i = blockIdx.x, j = threadIdx.x;
    double a = 0.0, b = 1.0;
    if (j < D) {
        const real* x = X + (size_t)i * D;
        fit_term(func, j, D, (double)x[j], (j + 1 < D) ? (double)x[j + 1] : 0.0,
                 (double)o[j], (j + 1 < D) ? (double)o[j + 1] : 0.0, a, b);
    }
    sa[j] = a; sb[j] = b;
    __syncthreads();
    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (j < s) { sa[j] += sa[j + s]; sb[j] *= sb[j + s]; }
        __syncthreads();
    }
    if (j == 0) fit[i] = fit_final(func, sa[0], sb[0]);
}

// kernel(P) : r1,r2,r3 mutually distinct and != i, plus j_rand  -> idx[4*i .. 4*i+3]
// DE kernel P (Parents) : 1 thread = 1 individu. Tire r1, r2, r3 (differents entre eux et de i)
// et la coordonnee jrand. Resultat range dans idx[4*i .. 4*i+3].
__global__ void de_P(RNG* stP, int* idx, int P, int D)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= P) return;
    RNG s = stP[i];
    int r1, r2, r3;
    do { r1 = curand(&s) % P; } while (r1 == i);
    do { r2 = curand(&s) % P; } while (r2 == i || r2 == r1);
    do { r3 = curand(&s) % P; } while (r3 == i || r3 == r1 || r3 == r2);
    int jr = curand(&s) % D;
    stP[i] = s;
    reinterpret_cast<int4*>(idx)[i] = make_int4(r1, r2, r3, jr);
}

// kernel(M) : V = X_r1 + F (X_r2 - X_r3)
// DE kernel M (Mutation) : V = X_r1 + F * (X_r2 - X_r3), 1 thread = 1 coordonnee.
__global__ void de_M(const real* X, real* V, const int* idx, int n, int D, real F)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    int i = e / D, j = e - i * D;
    int4 id = reinterpret_cast<const int4*>(idx)[i];
    V[e] = X[(size_t)id.x * D + j] + F * (X[(size_t)id.y * D + j] - X[(size_t)id.z * D + j]);
}

// kernel(C) : binomial crossover
// DE kernel C (Croisement) : 1 thread = 1 coordonnee. Prend le mutant si rand <= CR ou si j = jrand,
// sinon garde la valeur du parent.
__global__ void de_C(const real* X, const real* V, real* U, const int* idx, RNG* stE, int n, int D, real CR)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    int i = e / D, j = e - i * D;
    RNG s = stE[e];
    real u = (real)curand_uniform_double(&s);
    stE[e] = s;
    int jr = idx[4 * i + 3];
    U[e] = (u <= CR || j == jr) ? V[e] : X[e];
}

// kernel(R) : greedy replacement (X in place : only its own element is touched)
// DE kernel R (Remplacement) : l'enfant remplace le parent s'il est meilleur (selection gloutonne).
__global__ void de_R(real* X, const real* U, const double* fit, const double* fitU, double* fitNext, int n, int D)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    int i = e / D;
    bool acc = fitU[i] < fit[i];
    if (acc) X[e] = U[e];
    if (e - i * D == 0) fitNext[i] = acc ? fitU[i] : fit[i];
}

// Rapatrie le resultat : recupere les fitness, trouve le meilleur individu et le copie sur le CPU.
static OptResult de_collect(const real* X, const double* fit, int P, int D, double t0, double t1, long long G)
{
    OptResult r;
    std::vector<double> hf(P);
    CUDA_CHECK(cudaMemcpy(hf.data(), fit, P * sizeof(double), cudaMemcpyDeviceToHost));
    int b = 0;
    for (int i = 1; i < P; i++) if (hf[i] < hf[b]) b = i;
    r.bestFit = hf[b];
    r.gBest.resize(D);
    CUDA_CHECK(cudaMemcpy(r.gBest.data(), X + (size_t)b * D, D * sizeof(real), cudaMemcpyDeviceToHost));
    r.timeMs = t1 - t0; r.iters = (int)G; r.fe = (long long)P * (1 + G);
    return r;
}

// DE-GPU de base : a chaque generation on enchaine 5 kernels P -> M -> C -> E -> R.
// Chaque kernel est lance separement : simple, mais beaucoup de lancements et de lectures memoire.
OptResult cuda_de(const OptParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 4 || D < 1 || (int)shift.size() < D) { fprintf(stderr, "cuda_de: invalid parameters (pop >= 4)\n"); exit(1); }
    const BenchInfo bi = bench_info(prm.func);
    const int n = P * D;
    long long G = prm.maxFE / P - 1; if (G < 0) G = 0;
    const real lo = (real)bi.lo, hi = (real)bi.hi;

    real *X = dmalloc<real>(n), *V = dmalloc<real>(n), *U = dmalloc<real>(n), *o = dmalloc<real>(D);
    double *fit = dmalloc<double>(P), *fit2 = dmalloc<double>(P), *fitU = dmalloc<double>(P);
    int* idx = dmalloc<int>(4 * P);
    RNG *stE = dmalloc<RNG>(n), *stP = dmalloc<RNG>(P);
    CUDA_CHECK(cudaMemcpy(o, shift.data(), D * sizeof(real), cudaMemcpyHostToDevice));
    // eB = threads par bloc pour le kernel E (puissance de 2 >= D, minimum 32).
    const int eB = std::max(32, next_pow2(D));
    const size_t eSmem = 2 * eB * sizeof(double);

    CUDA_CHECK(cudaDeviceSynchronize());
    double t0 = now_ms();
    de_I<<<nblk(n), TB>>>(X, stE, stP, n, P, lo, hi, prm.seed);
    de_E<<<P, eB, eSmem>>>(X, fit, D, prm.func, o);
    for (long long g = 0; g < G; g++) {
        // Une generation (version de base) : Parents -> Mutation -> Croisement -> Evaluation -> Remplacement.
        de_P<<<nblk(P), TB>>>(stP, idx, P, D);
        de_M<<<nblk(n), TB>>>(X, V, idx, n, D, (real)prm.F);
        de_C<<<nblk(n), TB>>>(X, V, U, idx, stE, n, D, (real)prm.CR);
        de_E<<<P, eB, eSmem>>>(U, fitU, D, prm.func, o);
        de_R<<<nblk(n), TB>>>(X, U, fit, fitU, fit2, n, D);
        // Echange les tampons de fitness : "suivant" devient "courant".
        std::swap(fit, fit2);
    }
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
    double t1 = now_ms();

    OptResult r = de_collect(X, fit, P, D, t0, t1, G);
    cudaFree(X); cudaFree(V); cudaFree(U); cudaFree(o); cudaFree(fit); cudaFree(fit2); cudaFree(fitU);
    cudaFree(idx); cudaFree(stE); cudaFree(stP);
    return r;
}
