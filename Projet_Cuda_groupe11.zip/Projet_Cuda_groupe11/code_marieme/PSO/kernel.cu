// ============================================================================
//  kernel.cu - PSO-GPU (kernels I, E, G, U)
//   disposition "coordonnee d'abord" (element e = d*P + p) : acces memoire coalesces
//   mise a jour synchrone, cuRAND Philox, fitness calcule en double.
//   Chronometrage : horloge murale entre deux cudaDeviceSynchronize(), allocations
//   et creation du contexte CUDA exclues (echauffement dans main).
// ============================================================================
#include "kernel.h"
#include <chrono>
#include <cuda_runtime.h>
#include <curand_kernel.h>

// Affiche l'erreur CUDA et arrete le programme si un appel GPU echoue.
#define CUDA_CHECK(x) do { cudaError_t e_ = (x); if (e_ != cudaSuccess) { \
    fprintf(stderr, "CUDA error '%s' at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); exit(1); } } while (0)

// RNG = generateur aleatoire du GPU (Philox) : un "etat" par thread, donc sans conflit.
typedef curandStatePhilox4_32_10_t RNG;
// TB = nombre de threads par bloc pour les kernels simples.
static const int TB = 256;                       // threads/block of the element-wise kernels
static inline int nblk(long long n) { return (int)((n + TB - 1) / TB); }
static inline int next_pow2(int v) { int p = 1; while (p < v) p <<= 1; return p; }

template <typename T> static T* dmalloc(size_t n) { T* p; CUDA_CHECK(cudaMalloc(&p, n * sizeof(T))); return p; }

// Chronometre (ms). On mesure entre deux cudaDeviceSynchronize pour inclure tout le travail GPU.
static double now_ms()
{
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// ===========================================================================
//  PSO-GPU
//  position/velocity/pBest stored coordinate-major : element e = d*P + p
// ===========================================================================
// PSO kernel I (Init) : 1 thread = 1 valeur (particule p, coordonnee d). Position aleatoire, vitesse 0.
__global__ void pso_I(real* pos, real* vel, real* pbest, double* pfit, RNG* st,
                      int n, int P, real lo, real hi, unsigned long long seed)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    RNG s; curand_init(seed, e, 0, &s);
    real x = lo + (hi - lo) * (real)curand_uniform_double(&s);
    pos[e] = x; pbest[e] = x; vel[e] = (real)0; st[e] = s;
    if (e < P) pfit[e] = 1.0e300;
}

// one thread per particle (fitness read with stride P) + pBest update
// PSO kernel E (Evaluation) : 1 thread = 1 particule. Calcule son fitness et met a jour son pBest.
__global__ void pso_E(const real* pos, real* pbest, double* pfit, int P, int D, int func, const real* o)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= P) return;
    double f = fitness(pos + p, P, D, func, o);
    if (f < pfit[p]) {
        pfit[p] = f;
        for (int d = 0; d < D; d++) pbest[(size_t)d * P + p] = pos[(size_t)d * P + p];
    }
}

// single block (blockDim = power of two >= P, <= 1024) : argmin of pBest fitness
// PSO kernel G (Global best) : UN bloc cherche le plus petit fitness parmi les particules
// (reduction en arbre : on compare les valeurs par paires, puis par paires de paires...).
__global__ void pso_G(const double* pfit, const real* pbest, real* gbest, double* gfit, int P, int D)
{
    __shared__ double sv[1024];
    __shared__ int    si[1024];
    int t = threadIdx.x;
    double v = 1.0e300; int id = 0;
    for (int p = t; p < P; p += blockDim.x) if (pfit[p] < v) { v = pfit[p]; id = p; }
    sv[t] = v; si[t] = id;
    __syncthreads();
    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (t < s && (sv[t + s] < sv[t] || (sv[t + s] == sv[t] && si[t + s] < si[t]))) { sv[t] = sv[t + s]; si[t] = si[t + s]; }
        __syncthreads();
    }
    bool better = sv[0] < *gfit;
    __syncthreads();
    if (better) {
        for (int d = t; d < D; d += blockDim.x) gbest[d] = pbest[(size_t)d * P + si[0]];
        if (t == 0) *gfit = sv[0];
    }
}

// PSO kernel U (Update) : 1 thread = 1 valeur. Applique la formule vitesse/position, avec ses
// propres nombres aleatoires r1, r2 (meme formule que le CPU).
__global__ void pso_U(real* pos, real* vel, const real* pbest, const real* gbest, RNG* st,
                      int n, int P, real w, real c1, real c2, real vmax, real lo, real hi)
{
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n) return;
    int d = e / P;
    RNG s = st[e];
    real r1 = (real)curand_uniform_double(&s), r2 = (real)curand_uniform_double(&s);
    st[e] = s;
    real x = pos[e];
    real v = w * vel[e] + c1 * r1 * (pbest[e] - x) + c2 * r2 * (gbest[d] - x);
    if (v >  vmax) v =  vmax;
    if (v < -vmax) v = -vmax;
    x += v;
    if (x < lo)      { x = lo; v = (real)0; }
    else if (x > hi) { x = hi; v = (real)0; }
    vel[e] = v; pos[e] = x;
}

// PSO-GPU : reserve la memoire, puis repete U -> E -> G a chaque generation.
// Disposition "coordonnee d'abord" (e = d*P + p) : des threads voisins lisent des cases voisines,
// ce qui accelere les acces memoire (acces coalesces).
OptResult cuda_pso(const OptParams& prm, const std::vector<real>& shift)
{
    const int P = prm.pop, D = prm.dim;
    if (P < 2 || P > 1024 || D < 1 || (int)shift.size() < D) { fprintf(stderr, "cuda_pso: invalid parameters (2 <= pop <= 1024)\n"); exit(1); }
    const BenchInfo bi = bench_info(prm.func);
    const int n = P * D;
    long long nIter = prm.maxFE / P - 1; if (nIter < 0) nIter = 0;
    const real lo = (real)bi.lo, hi = (real)bi.hi, vmax = (real)(prm.vmaxFrac * (bi.hi - bi.lo));

    real *pos = dmalloc<real>(n), *vel = dmalloc<real>(n), *pbest = dmalloc<real>(n);
    real *gbest = dmalloc<real>(D), *o = dmalloc<real>(D);
    double *pfit = dmalloc<double>(P), *gfit = dmalloc<double>(1);
    RNG* st = dmalloc<RNG>(n);
    CUDA_CHECK(cudaMemcpy(o, shift.data(), D * sizeof(real), cudaMemcpyHostToDevice));
    double inf = 1.0e300;
    CUDA_CHECK(cudaMemcpy(gfit, &inf, sizeof(double), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(gbest, 0, D * sizeof(real)));
    const int gB = next_pow2(P);

    CUDA_CHECK(cudaDeviceSynchronize());
    double t0 = now_ms();
    // --- Lancement : I, E, G une fois, puis la boucle ---
    pso_I<<<nblk(n), TB>>>(pos, vel, pbest, pfit, st, n, P, lo, hi, prm.seed);
    pso_E<<<nblk(P), TB>>>(pos, pbest, pfit, P, D, prm.func, o);
    pso_G<<<1, gB>>>(pfit, pbest, gbest, gfit, P, D);
    // Une generation = U (bouger) -> E (evaluer) -> G (meilleur global).
    for (long long it = 0; it < nIter; it++) {
        real w = (real)((nIter > 1) ? prm.wMax - (prm.wMax - prm.wMin) * (double)it / (double)(nIter - 1) : prm.wMax);
        pso_U<<<nblk(n), TB>>>(pos, vel, pbest, gbest, st, n, P, w, (real)prm.c1, (real)prm.c2, vmax, lo, hi);
        pso_E<<<nblk(P), TB>>>(pos, pbest, pfit, P, D, prm.func, o);
        pso_G<<<1, gB>>>(pfit, pbest, gbest, gfit, P, D);
    }
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
    double t1 = now_ms();

    OptResult r;
    r.gBest.resize(D);
    CUDA_CHECK(cudaMemcpy(r.gBest.data(), gbest, D * sizeof(real), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&r.bestFit, gfit, sizeof(double), cudaMemcpyDeviceToHost));
    r.timeMs = t1 - t0; r.iters = (int)nIter; r.fe = (long long)P * (1 + nIter);
    cudaFree(pos); cudaFree(vel); cudaFree(pbest); cudaFree(gbest); cudaFree(o);
    cudaFree(pfit); cudaFree(gfit); cudaFree(st);
    return r;
}
