# PSO sur CPU et GPU (CUDA)

Algorithmes : **PSO-CPU** (séquentiel) et **PSO-GPU** (4 kernels : I, E, G, U).

| Fichier | Rôle |
|---|---|
| kernel.h | fonctions de test décalées (CEC2005), paramètres, déclarations |
| kernel.cpp | PSO-CPU, vecteurs de décalage |
| kernel.cu | PSO-GPU |
| main.cpp | programme principal : runs, moyenne/écart-type, temps, taux de succès, CSV |
| notebook_pso.ipynb | notebook (Kaggle ou Colab, GPU) : compile, teste, lance le protocole, tableaux, figures, tests statistiques |

## Principe (PSO synchrone)
Vitesse : `v = w·v + c1·r1·(pBest − x) + c2·r2·(gBest − x)`, puis `x = x + v`.
Paramètres : w de 0,9 à 0,4, c1 = c2 = 2, vitesse limitée à 0,2 × l'étendue du domaine.
Le meilleur global est mis à jour une fois par itération. Budget : MaxFEs = 10⁴·D, soit ⌊MaxFEs/P⌋ − 1 itérations.

## Compiler et lancer
    nvcc -O3 -std=c++17 -arch=sm_75 kernel.cu kernel.cpp main.cpp -o pso
    ./pso --verify
    ./pso --algo pso-cpu,pso-gpu --func 4 --dim 50 --pop 100 --runs 10 --seed 1234
    ./pso --sweep --out resultats_pso.csv
Sans GPU : `g++ -O2 -std=c++17 -DNO_CUDA kernel.cpp main.cpp -o pso` (PSO-CPU seulement).
`--func` : 1 Rastrigin, 2 Rosenbrock, 3 Griewank, 4 Sphere.

## Notebook
Sur Kaggle : créer un dataset avec `kernel.h kernel.cpp kernel.cu main.cpp`, l'ajouter au notebook, activer le GPU, puis *Run All* (`QUICK = False` pour le protocole officiel à 10 exécutions).
