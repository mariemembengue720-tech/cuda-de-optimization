#!/usr/bin/env python3
"""Analyse complète : CSV bruts -> all_runs.csv, tableaux LaTeX, tests statistiques, figures EN FRANÇAIS.

Usage :  python3 analyse.py  ENTREE  [SORTIE_DIR]
  ENTREE : un CSV (issu de  ./cudade --sweep --out ...)  ou un dossier contenant des CSV.
  SORTIE_DIR (défaut : resultats/) reçoit : all_runs.csv, tests_mw_holm.csv, gen/*.tex, figures/*.png
"""
import sys, glob, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats

src = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else 'resultats'
os.makedirs(out + '/gen', exist_ok=True); os.makedirs(out + '/figures', exist_ok=True)

files = sorted(glob.glob(src + '/*.csv')) if os.path.isdir(src) else [src]
d = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
if 'time_s' not in d: d['time_s'] = d.time_ms / 1000.0
d = d.drop_duplicates(['algo', 'func', 'dim', 'pop', 'run'])
d.to_csv(out + '/all_runs.csv', index=False)

A = ['PSO-CPU', 'PSO-GPU', 'DE-CPU', 'DE-GPU', 'DE-GPU-OPT']
COL = dict(zip(A, ['#E69F00', '#D55E00', '#56B4E9', '#009E73', '#0072B2']))   # palette Okabe-Ito (distincte, daltonisme)
HAT = dict(zip(A, ['//', '', '//', '', '']))                                  # hachures : versions CPU
F = ['Sphere', 'Rosenbrock', 'Griewank', 'Rastrigin']
DIMS, POPS = [10, 50, 100], [50, 100, 500]
print(f"{len(d)} exécutions (attendu 1800) ; fe==P(1+G) :",
      ((d.fe == d['pop'] * (d.dim * 10000 // d['pop'])) .mean()).round(3))

# ------------------------------------------------------------------ tableaux
tm = d.groupby(['algo', 'dim', 'pop']).time_ms.mean()          # ms
def tex_row(D, P, vals, fmt): return f"{D} & {P} & " + " & ".join(fmt.format(v) for v in vals) + r" \\\hline"
rows_t, rows_s, rows_g = [], [], []
for D in DIMS:
    for P in POPS:
        t = {a: tm[(a, D, P)] for a in A}
        G = D * 10000 // P - 1
        rows_t.append(tex_row(D, P, [t[a] for a in A], "{:.1f}"))
        rows_g.append(tex_row(D, P, [t[a] * 1000 / G for a in A], "{:.1f}"))
        rows_s.append(tex_row(D, P, [t['PSO-CPU'] / t['PSO-GPU'], t['DE-CPU'] / t['DE-GPU'],
                                      t['DE-CPU'] / t['DE-GPU-OPT'], t['DE-GPU'] / t['DE-GPU-OPT']], "{:.2f}"))
open(out + '/gen/time_rows.tex', 'w').write("\n".join(rows_t) + "\n")
open(out + '/gen/usgen_rows.tex', 'w').write("\n".join(rows_g) + "\n")
open(out + '/gen/speed_rows_ratio.tex', 'w').write("\n".join(rows_s) + "\n")

def _f(x):
    if x < 1e-8: return "0"
    if x >= 1e4 or x < 1e-2:
        m, e = f"{x:.1e}".split("e"); return f"{m}e{int(e)}"
    if x>=1e3: return f"{x:.0f}"
    return f"{x:.3g}"
g = d.groupby(['func', 'dim', 'pop', 'algo']).error.agg(['mean', 'std'])
tabs = []
for D in DIMS:
    rows = []
    for f in F:
        for i, P in enumerate(POPS):
            cells = [f"{_f(g.loc[(f, D, P, a), 'mean'])} ({_f(g.loc[(f, D, P, a), 'std'])})" for a in A]
            head = f"\\multirow{{3}}{{*}}{{{f}}}" if i == 0 else ""
            rows.append(f"{head} & {P} & " + " & ".join(cells) + (r" \\\hline" if i == 2 else r" \\\cline{2-7}"))
    tabs.append(r"""\begin{table*}[!t]\centering\scriptsize\setlength{\tabcolsep}{4pt}
\caption{EFV : moyenne (écart-type) sur 10 exécutions pour les cinq architectures, $D=%d$. Valeurs inférieures à $10^{-8}$ affichées $0$.}
\label{tab:all%d}
\begin{tabular}{|l|r|c|c|c|c|c|}\hline
Fonction & $P$ & PSO-CPU & PSO-GPU & DE-CPU & DE-GPU & \optname\\\hline
%s
\end{tabular}
\end{table*}
""" % (D, D, "\n".join(rows)))
open(out + '/gen/efv_all_tables.tex', 'w').write("\n".join(tabs))

# ------------------------------------------------------------------ statistiques
pairs = [('DE-GPU-OPT', 'DE-CPU'), ('DE-GPU-OPT', 'DE-GPU'), ('DE-GPU-OPT', 'PSO-GPU'), ('DE-CPU', 'PSO-CPU'), ('DE-GPU', 'DE-CPU')]
rows = []
for (f, D, P), gr in d.groupby(['func', 'dim', 'pop']):
    r = dict(func=f, dim=D, pop=P)
    a = {k: v.sort_values('run').error.values for k, v in gr.groupby('algo')}
    for x, y in pairs:
        both = np.concatenate([a[x], a[y]])
        r[f'{x}|{y}'] = 1.0 if np.ptp(both) < 1e-9 else stats.mannwhitneyu(a[x], a[y], alternative='two-sided').pvalue
    allv = np.concatenate(list(a.values()))
    r['KW'] = stats.kruskal(*a.values()).pvalue if np.ptp(allv) > 1e-9 else 1.0
    rows.append(r)
s = pd.DataFrame(rows)
def holm(p):
    p = np.array(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for i, idx in enumerate(o):
        run = max(run, (m - i) * p[idx]); adj[idx] = min(1, run)
    return adj
cols = [c for c in s.columns if '|' in c] + ['KW']
for c in cols: s[c + '_holm'] = holm(s[c])
s.to_csv(out + '/tests_mw_holm.csv', index=False)
print("Cas significatifs (p<0,05), brut / Holm, sur 36 :")
for c in cols: print(f"  {c:22s} {(s[c] < .05).sum():2d} / {(s[c + '_holm'] < .05).sum():2d}")

# ------------------------------------------------------------------ figures (français)
plt.rcParams.update({'font.size': 9})
# 1) temps par fonction
for k, f in zip([3, 4, 5, 6], F):
    fig, ax = plt.subplots(3, 1, figsize=(9, 8.6), sharex=True)
    w = 0.16
    for r, D in enumerate(DIMS):
        for j, a in enumerate(A):
            m = [d[(d.func == f) & (d.dim == D) & (d['pop'] == P) & (d.algo == a)].time_s.mean() for P in POPS]
            sd = [d[(d.func == f) & (d.dim == D) & (d['pop'] == P) & (d.algo == a)].time_s.std() for P in POPS]
            ax[r].bar(np.arange(3) + (j - 2) * w, m, w, yerr=sd, color=COL[a], hatch=HAT[a], edgecolor='white', label=a, capsize=1.5, error_kw=dict(lw=.8))
        ax[r].set_yscale('log'); ax[r].set_ylabel(f'Temps D={D} (s)'); ax[r].grid(alpha=.3, axis='y')
    ax[2].set_xticks(range(3)); ax[2].set_xticklabels([f'P={P}' for P in POPS])
    fig.suptitle(f'Temps de calcul moyen — {f}'); fig.legend(*ax[0].get_legend_handles_labels(), loc='upper center', ncol=5, bbox_to_anchor=(.5, .955), fontsize=8)
    fig.tight_layout(rect=(0, 0, 1, .93)); fig.savefig(f'{out}/figures/fig_time_{k}_{f}.png', dpi=150); plt.close(fig)
# 2) qualité
from matplotlib.lines import Line2D
fig, ax = plt.subplots(1, 4, figsize=(16, 4.2))
ls = {10: '-', 50: '--', 100: ':'}
MK = dict(zip(A, ['s', '^', 'o', 'v', 'D']))
for a_, f in zip(ax, F):
    for al in A:
        for D in DIMS:
            m = [max(d[(d.func == f) & (d.dim == D) & (d['pop'] == P) & (d.algo == al)].error.mean(), 1e-12) for P in POPS]
            a_.plot(range(3), m, ls[D], color=COL[al], marker=MK[al], ms=4, lw=1.6)
    a_.set_yscale('log'); a_.set_xticks(range(3)); a_.set_xticklabels([f'P={P}' for P in POPS]); a_.set_title(f, fontsize=11); a_.grid(alpha=.3)
    a_.tick_params(labelsize=9)
ax[0].set_ylabel('EFV moyenne (plancher à $10^{-12}$)', fontsize=10)
h1 = [Line2D([0], [0], color=COL[al], marker=MK[al], lw=2, label=al) for al in A]
h2 = [Line2D([0], [0], color='k', ls=ls[D], lw=1.8, label=f'D = {D}') for D in DIMS]
l1 = fig.legend(handles=h1, loc='lower center', ncol=5, fontsize=11, bbox_to_anchor=(.38, 0), frameon=False, title='Algorithme (couleur)', title_fontsize=10)
fig.legend(handles=h2, loc='lower center', ncol=3, fontsize=11, bbox_to_anchor=(.80, 0), frameon=False, title='Dimension (style de trait)', title_fontsize=10)
fig.tight_layout(rect=(0, .17, 1, 1)); fig.savefig(out + '/figures/fig_quality.png', dpi=170); plt.close(fig)
# 3) carte thermique
M = np.array([[tm[('DE-CPU', D, P)] / tm[('DE-GPU-OPT', D, P)] for P in POPS] for D in DIMS])
fig, ax = plt.subplots(figsize=(4.2, 3.2)); im = ax.imshow(M, cmap='viridis')
for i in range(3):
    for j in range(3): ax.text(j, i, f'{M[i, j]:.1f}×', ha='center', va='center', color='white' if M[i, j] < M.max() * .7 else 'black')
ax.set_xticks(range(3)); ax.set_xticklabels([f'P={P}' for P in POPS]); ax.set_yticks(range(3)); ax.set_yticklabels([f'D={D}' for D in DIMS])
ax.set_title('DE-GPU-OPT contre DE-CPU'); fig.colorbar(im, label='accélération')
fig.tight_layout(); fig.savefig(out + '/figures/fig_speedup_heatmap.png', dpi=200); plt.close(fig)
# 4) temps en fonction de P
fig, ax = plt.subplots(1, 3, figsize=(9, 2.8))
for a_, D in zip(ax, DIMS):
    for al, mk in zip(A, ['s', '^', 'o', 'v', 'D']):
        a_.plot(POPS, [tm[(al, D, P)] / 1000 for P in POPS], marker=mk, ms=4, label=al, color=COL[al])
    a_.set_xscale('log'); a_.set_yscale('log'); a_.set_xticks(POPS); a_.set_xticklabels(POPS)
    a_.set_title(f'D = {D}', fontsize=9); a_.set_xlabel('Taille de population P'); a_.grid(alpha=.3)
ax[0].set_ylabel('Temps moyen (s)'); ax[0].legend(fontsize=6)
fig.tight_layout(); fig.savefig(out + '/figures/fig_timecurve.png', dpi=200); plt.close(fig)
print("Terminé :", out)
